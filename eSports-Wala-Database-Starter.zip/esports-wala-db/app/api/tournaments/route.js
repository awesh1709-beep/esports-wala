import {prisma} from "../../../lib/prisma";
export async function GET(){const data=await prisma.tournament.findMany({where:{status:"OPEN"},orderBy:{eventDate:"asc"}});return Response.json(data)}