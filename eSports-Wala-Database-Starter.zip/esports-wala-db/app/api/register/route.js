import {prisma} from "../../../lib/prisma";
export async function POST(req){
 try{const b=await req.json();for(const k of ["teamName","captainName","captainUid","contact","tournamentId"])if(!b[k])return Response.json({error:`Missing ${k}`},{status:400});
 const t=await prisma.tournament.findUnique({where:{id:b.tournamentId}});if(!t||t.status!=="OPEN")return Response.json({error:"Tournament unavailable"},{status:400});
 const count=await prisma.registration.count({where:{tournamentId:t.id,status:{in:["PENDING","APPROVED"]}}});if(count>=t.slots)return Response.json({error:"Tournament is full"},{status:409});
 await prisma.registration.create({data:{teamName:b.teamName,captainName:b.captainName,captainUid:b.captainUid,contact:b.contact,tournamentId:t.id}});
 return Response.json({message:"Registration submitted successfully. Waiting for admin approval."},{status:201})
 }catch(e){return Response.json({error:"Server error"},{status:500})}}