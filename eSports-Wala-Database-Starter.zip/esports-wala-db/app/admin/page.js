import {prisma} from "../../lib/prisma";
export default async function Admin(){
 const regs=await prisma.registration.findMany({include:{tournament:true},orderBy:{createdAt:"desc"},take:50});
 return <main className="page"><a href="/">← Home</a><div className="eyebrow">ADMIN</div><h1>Registration Dashboard</h1><p className="muted">This page is intentionally read-only in this starter. Add secure authentication before enabling approve/reject actions.</p><div className="table"><div className="tr head"><span>Team</span><span>Captain</span><span>Tournament</span><span>Status</span></div>{regs.map(r=><div className="tr" key={r.id}><span>{r.teamName}</span><span>{r.captainName}</span><span>{r.tournament.name}</span><span>{r.status}</span></div>)}</div></main>}
